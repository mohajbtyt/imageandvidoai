'use strict';
(function () {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const store = {
    get(k) { try { return localStorage.getItem(k); } catch (_) { return null; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch (_) { /* ignore */ } },
    sget(k) { try { return sessionStorage.getItem(k); } catch (_) { return null; } },
    sset(k, v) { try { if (v === null) sessionStorage.removeItem(k); else sessionStorage.setItem(k, v); } catch (_) { /* ignore */ } },
  };

  let lang = store.get('enhanceai.lang') || (/^ar/i.test(navigator.language || '') ? 'ar' : 'en');
  if (!window.I18N[lang]) lang = 'ar';
  let config = null;
  const controllers = [];

  const t = (k, vars) => {
    let s = (window.I18N[lang] && window.I18N[lang][k]) || window.I18N.en[k] || k;
    if (vars) for (const [a, b] of Object.entries(vars)) s = s.replace(`{${a}}`, b);
    return s;
  };
  const fmtSize = (b) => (b >= 1048576 ? (b / 1048576).toFixed(2) + ' MB' : (b / 1024).toFixed(1) + ' KB');
  const fmtDur = (s) => Number(s).toFixed(2) + ' s';

  function applyLang() {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    $('#langBtn').textContent = lang === 'ar' ? 'EN' : 'عربي';
    $$('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });
    const n = config ? config.retentionMinutes : 30;
    $('[data-el=privacyText]').textContent = t('privacy.text', { n });
    controllers.forEach((c) => c.render());
  }

  // ---------------- Tabs ----------------
  function selectTab(type) {
    for (const tab of $$('.tab')) {
      const on = tab.id === 'tab-' + type;
      tab.setAttribute('aria-selected', on ? 'true' : 'false');
      tab.tabIndex = on ? 0 : -1;
    }
    $$('.panel').forEach((p) => { p.hidden = p.dataset.type !== type; });
  }
  $$('.tab').forEach((tab) => {
    tab.addEventListener('click', () => selectTab(tab.id.replace('tab-', '')));
    tab.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') { const next = tab.id === 'tab-image' ? 'video' : 'image'; selectTab(next); $('#tab-' + next).focus(); }
    });
  });

  // ---------------- Per-tab controller ----------------
  class Controller {
    constructor(root) {
      this.root = root; this.type = root.dataset.type;
      this.el = {}; $$('[data-el]', root).forEach((e) => { this.el[e.dataset.el] = e; });
      this.file = null; this.objectUrl = null; this.job = null; this.pollTimer = null;
      this.phase = 'idle'; // idle | sending | running | done | failed
      this.sendPct = 0; this.error = null; this.clientNote = null; this.startedAt = 0; this.tick = null;
      this.sourceShortSide = 0; this.sourceInfo = null;
      this.el.file.addEventListener('change', () => this.onPick());
      this.el.go.addEventListener('click', () => this.submit());
    }
    get busy() { return this.phase === 'sending' || this.phase === 'running'; }
    get avail() { return config && config[this.type].available; }

    onPick() {
      const f = this.el.file.files && this.el.file.files[0];
      if (!f) return;
      this.reset(true);
      const lim = config[this.type];
      const okExt = this.type === 'image' ? /\.(jpe?g|png|webp)$/i : /\.mp4$/i;
      const okMime = this.type === 'image' ? /^image\/(jpeg|png|webp)$/ : /^video\/mp4$/;
      if (!okExt.test(f.name) && !okMime.test(f.type)) return this.fail({ local: 'err.TYPE' });
      if (f.size > lim.maxMB * 1048576) return this.fail({ local: 'err.SIZE', vars: { n: lim.maxMB } });
      this.file = f;
      this.objectUrl = URL.createObjectURL(f);
      this.el.originalCard.hidden = false; this.el.options.hidden = false; this.el.go.hidden = false;
      if (this.type === 'image') {
        this.el.originalImg.src = this.objectUrl;
        this.el.originalMeta.textContent = `${f.name} · ${fmtSize(f.size)}`;
      } else {
        this.el.originalVideo.src = this.objectUrl;
        this.el.originalMeta.textContent = `${f.name} · ${fmtSize(f.size)}`;
        this.el.originalVideo.onloadedmetadata = () => this.onVideoMeta();
        this.el.originalVideo.onerror = () => { this.clientNote = { key: 'err.METADATA' }; this.render(); };
      }
      this.render();
    }

    onVideoMeta() {
      const v = this.el.originalVideo; const lim = config.video;
      this.sourceShortSide = Math.min(v.videoWidth, v.videoHeight);
      this.el.originalMeta.textContent = `${this.file.name} · ${fmtSize(this.file.size)} · ${v.videoWidth}×${v.videoHeight} · ${fmtDur(v.duration)}`;
      this.clientNote = null;
      if (Number.isFinite(v.duration) && v.duration >= lim.maxSecondsExclusive) {
        this.clientNote = { key: 'err.DURATION', vars: { d: v.duration.toFixed(1), m: lim.maxSecondsExclusive }, blocking: true };
      }
      const need = { '720p': 720, '1080p': 1080, '4k': 2160 };
      let firstOk = null;
      $$('input[name=resolution]', this.root).forEach((r) => {
        r.disabled = this.sourceShortSide >= need[r.value];
        if (!r.disabled && !firstOk) firstOk = r;
      });
      const checked = $('input[name=resolution]:checked', this.root);
      if ((!checked || checked.disabled) && firstOk) firstOk.checked = true;
      if (!firstOk) this.clientNote = { key: 'err.NOHIGHER', blocking: true };
      this.render();
    }

    reset(keepInput) {
      clearTimeout(this.pollTimer); clearInterval(this.tick);
      if (this.objectUrl) URL.revokeObjectURL(this.objectUrl);
      this.objectUrl = null; this.file = null; this.job = null; this.phase = 'idle'; this.error = null; this.clientNote = null; this.sendPct = 0;
      store.sset('enhanceai.job.' + this.type, null);
      if (!keepInput) this.el.file.value = '';
      this.el.originalCard.hidden = true; this.el.options.hidden = true; this.el.go.hidden = true;
      $$('input[name=resolution]', this.root).forEach((r) => { r.disabled = false; });
      this.render();
    }

    fail(err) { this.phase = 'failed'; this.error = err; clearInterval(this.tick); this.render(); }

    params() {
      if (this.type === 'image') {
        return `type=image&scale=${$('input[name=scale]:checked', this.root).value}&face_enhance=${this.el.face.checked ? 1 : 0}`;
      }
      return `type=video&resolution=${$('input[name=resolution]:checked', this.root).value}`;
    }

    submit() {
      if (!this.file || this.busy || !this.avail) return;
      if (this.clientNote && this.clientNote.blocking) return;
      this.error = null; this.phase = 'sending'; this.sendPct = 0; this.startedAt = Date.now();
      clearInterval(this.tick); this.tick = setInterval(() => this.renderElapsed(), 1000);
      const xhr = new XMLHttpRequest();
      xhr.open('POST', '/api/jobs?' + this.params());
      xhr.setRequestHeader('Content-Type', this.file.type || 'application/octet-stream');
      xhr.setRequestHeader('X-File-Name', encodeURIComponent(this.file.name));
      if (config.accessCodeRequired) xhr.setRequestHeader('X-Access-Code', $('#accessInput').value);
      xhr.upload.onprogress = (e) => { if (e.lengthComputable) { this.sendPct = Math.round((e.loaded / e.total) * 100); this.renderProgress(); } };
      xhr.onerror = () => this.fail({ local: 'err.NETWORK' });
      xhr.onload = () => {
        let body = null; try { body = JSON.parse(xhr.responseText); } catch (_) { /* ignore */ }
        if (xhr.status === 200 || xhr.status === 202) { this.setJob(body.job); this.phase = 'running'; store.sset('enhanceai.job.' + this.type, body.job.id); this.render(); this.poll(); }
        else this.fail(body && body.error ? { server: body.error } : { local: 'err.UNKNOWN' });
      };
      xhr.send(this.file);
      this.render();
    }

    setJob(j) { this.job = j; }

    async poll() {
      clearTimeout(this.pollTimer);
      if (!this.job) return;
      try {
        const r = await fetch('/api/jobs/' + this.job.id, { cache: 'no-store' });
        const body = await r.json();
        if (!r.ok) {
          store.sset('enhanceai.job.' + this.type, null);
          return this.fail(body.error ? { server: body.error } : { local: 'err.UNKNOWN' });
        }
        this.setJob(body.job);
        if (body.job.status === 'succeeded') { this.phase = 'done'; clearInterval(this.tick); this.render(); return; }
        if (body.job.status === 'failed') { store.sset('enhanceai.job.' + this.type, null); return this.fail({ server: body.job.error }); }
        this.render();
      } catch (_) { /* transient network problem: keep polling */ }
      this.pollTimer = setTimeout(() => this.poll(), 1500);
    }

    async resume() {
      const id = store.sget('enhanceai.job.' + this.type);
      if (!id) return;
      try {
        const r = await fetch('/api/jobs/' + id, { cache: 'no-store' });
        if (!r.ok) { store.sset('enhanceai.job.' + this.type, null); return; }
        const { job } = await r.json();
        this.job = job; this.startedAt = Date.now() - job.elapsedMs;
        if (job.status === 'running') { this.phase = 'running'; this.tick = setInterval(() => this.renderElapsed(), 1000); this.poll(); }
        else if (job.status === 'succeeded') this.phase = 'done';
        else return;
        this.render();
      } catch (_) { /* ignore */ }
    }

    async remove() {
      if (!this.job) return;
      try { await fetch('/api/jobs/' + this.job.id, { method: 'DELETE' }); } catch (_) { /* ignore */ }
      this.reset(false);
    }

    errText(err) {
      if (err.local) return { text: t(err.local, err.vars) };
      return { text: lang === 'ar' ? err.server.message_ar : err.server.message_en, detail: err.server.detail };
    }

    renderElapsed() {
      const n = this.el.job.querySelector('[data-elapsed]');
      if (n) n.textContent = `${t('elapsed')}: ${Math.floor((Date.now() - this.startedAt) / 1000)} s`;
    }
    renderProgress() {
      const bar = this.el.job.querySelector('[data-send-bar]'); if (bar) bar.style.width = this.sendPct + '%';
      const lab = this.el.job.querySelector('[data-send-pct]'); if (lab) lab.textContent = this.sendPct + '%';
    }

    stepIndex() {
      if (this.phase === 'sending') return 0;
      const order = ['queued', 'uploading', 'processing', 'downloading', 'verifying'];
      const s = this.job ? this.job.step : 'queued';
      if (s === 'done') return 5;
      return Math.max(1, order.indexOf(s)); // 'queued' is shown as the AI-service upload step
    }

    render() {
      // availability
      const un = this.el.unavailable;
      if (config && !this.avail) {
        un.hidden = false; un.textContent = t('unavail.' + (config[this.type].reason || 'LOAD'));
      } else if (!config) { un.hidden = false; un.textContent = t('unavail.LOAD'); } else un.hidden = true;
      this.el.dropzone.classList.toggle('disabled', !this.avail || this.busy);
      this.el.file.disabled = !this.avail || this.busy;
      this.el.go.disabled = !this.avail || this.busy || (this.clientNote && this.clientNote.blocking) || !this.file;
      $$('input', this.el.options).forEach((i) => { if (this.busy) i.disabled = true; else if (!(i.name === 'resolution' && this.sourceShortSide && this.sourceShortSide >= ({ '720p': 720, '1080p': 1080, '4k': 2160 })[i.value])) i.disabled = false; });

      const box = this.el.job; box.textContent = '';
      const add = (node) => box.appendChild(node);
      const mk = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text !== undefined) n.textContent = text; return n; };

      if (this.clientNote && this.phase === 'idle') {
        box.hidden = false;
        add(mk('div', 'notice ' + (this.clientNote.blocking ? 'err' : 'warn'), t(this.clientNote.key, this.clientNote.vars)));
      }
      if (this.phase === 'idle' && !this.clientNote) { box.hidden = true; return; }
      if (this.phase === 'idle') return;
      box.hidden = false;

      if (this.phase === 'sending' || this.phase === 'running') {
        const steps = ['sending', 'uploading', 'processing', 'downloading', 'verifying'];
        const cur = this.stepIndex();
        const ol = mk('ol', 'steps');
        steps.forEach((s, i) => {
          const li = mk('li', i < cur ? 'done' : i === cur ? 'active' : '');
          li.appendChild(mk('span', 'dot'));
          let label = t('step.' + s);
          if (s === 'processing' && i === cur && this.job && this.job.replicateStatus) label += ' — ' + t('rs.' + (this.job.replicateStatus === 'starting' ? 'starting' : 'processing'));
          li.appendChild(mk('span', '', label));
          if (s === 'sending' && i === cur) { const p = mk('span', '', ''); p.dataset.sendPct = ''; p.textContent = this.sendPct + '%'; p.style.marginInlineStart = 'auto'; li.appendChild(p); }
          ol.appendChild(li);
        });
        const bar = mk('div', 'bar' + (this.phase === 'sending' ? '' : ' indeterminate'));
        const fill = mk('i'); if (this.phase === 'sending') { fill.dataset.sendBar = ''; fill.style.width = this.sendPct + '%'; }
        bar.appendChild(fill);
        add(mk('div', 'card')); const card = box.lastChild;
        card.appendChild(ol); card.appendChild(mk('div', '', '')).style.height = '12px'; card.appendChild(bar);
        const el = mk('p', 'meta', ''); el.dataset.elapsed = ''; el.textContent = `${t('elapsed')}: ${Math.floor((Date.now() - this.startedAt) / 1000)} s`; card.appendChild(el);
      }

      if (this.phase === 'failed' && this.error) {
        const e = this.errText(this.error);
        const n = mk('div', 'notice err', e.text);
        if (e.detail) n.appendChild(mk('small', '', e.detail));
        add(n);
      }

      if (this.phase === 'done' && this.job && this.job.result) {
        const r = this.job.result; const o = this.job.original;
        const card = mk('div', 'card');
        card.appendChild(mk('div', 'notice ok-note', t('success'))).style.color = 'var(--ok)';
        const mb = mk('div', 'media-box'); mb.style.marginTop = '12px';
        if (this.type === 'image') { const im = mk('img'); im.src = r.url; im.alt = t('enhanced'); mb.appendChild(im); }
        else { const v = mk('video'); v.controls = true; v.playsInline = true; v.preload = 'metadata'; v.src = r.url; mb.appendChild(v); }
        card.appendChild(mb);
        const wrap = mk('div', 'table-wrap'); const tb = mk('table', 'cmp');
        const head = mk('tr'); ['', t('original'), t('enhanced')].forEach((h) => head.appendChild(mk('th', '', h))); tb.appendChild(head);
        const row = (label, a, b) => { const tr = mk('tr'); tr.appendChild(mk('th', '', label)); tr.appendChild(mk('td', 'v', a)); tr.appendChild(mk('td', 'v', b)); tb.appendChild(tr); };
        row(t('size'), fmtSize(o.size), fmtSize(r.size));
        row(t('resolution'), `${o.width}×${o.height}`, `${r.width}×${r.height}`);
        if (this.type === 'video') { row(t('duration'), fmtDur(o.duration), fmtDur(r.duration)); row(t('fps'), o.fps ? o.fps.toFixed(2) : '-', r.fps ? r.fps.toFixed(2) : '-'); }
        wrap.appendChild(tb); card.appendChild(wrap);
        card.appendChild(mk('p', 'meta', t('expires', { n: config ? config.retentionMinutes : 30 })));
        const actions = mk('div', 'actions'); actions.style.marginTop = '12px';
        const dl = mk('a', 'btn ok', t('download')); dl.href = r.downloadUrl; dl.setAttribute('download', r.filename); actions.appendChild(dl);
        const again = mk('button', 'btn', t('again')); again.type = 'button'; again.onclick = () => this.reset(false); actions.appendChild(again);
        const del = mk('button', 'btn', t('delete')); del.type = 'button'; del.onclick = () => this.remove(); actions.appendChild(del);
        card.appendChild(actions);
        add(card);
      }
    }
  }

  async function init() {
    $('#langBtn').addEventListener('click', () => { lang = lang === 'ar' ? 'en' : 'ar'; store.set('enhanceai.lang', lang); applyLang(); });
    $$('.panel').forEach((p) => controllers.push(new Controller(p)));
    applyLang();
    try {
      const r = await fetch('/api/config', { cache: 'no-store' });
      config = await r.json();
    } catch (_) { config = null; }
    applyLang();
    if (config && config.accessCodeRequired) {
      const box = $('#accessBox'); box.hidden = false;
      const inp = $('#accessInput'); inp.value = store.sget('enhanceai.access') || '';
      inp.addEventListener('input', () => store.sset('enhanceai.access', inp.value));
    }
    if (config) controllers.forEach((c) => c.resume());
  }
  init();
})();
